select title,max(stars)-min(stars) as spread from Movie, Rating 
where Movie.mID=Rating.mID group by title order by spread desc;