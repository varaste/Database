SELECT *
 FROM `movie`;
