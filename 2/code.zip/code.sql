SELECT distinct year
FROM Movie , Rating
WHERE stars=4 or stars=5;