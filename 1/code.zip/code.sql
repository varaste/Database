SELECT ${name}
 FROM `Movie` 
 WHERE director text = "Steven Spielberg"