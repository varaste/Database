SELECT title;
FROM Movie , Rating
WHERE stars not 0 and stars not 1 and stars not 2 and stars not 3 and stars not 4
and stars not 5;