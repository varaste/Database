SELECT title;
FROM Movie natural join Rating
WHERE stars is null