SELECT *
from student , apply , college
where state is null and decision is null and major = 'cs' and college.cName = Carnegie Mellom 